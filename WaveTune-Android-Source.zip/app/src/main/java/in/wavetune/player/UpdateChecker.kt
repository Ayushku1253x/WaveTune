package `in`.wavetune.player

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Configure these two values to match the GitHub repository that publishes WaveTune releases.
 * The app checks the public GitHub Releases API; no login token is needed for a public repo.
 */
private const val GITHUB_OWNER = "YOUR_GITHUB_USERNAME"
private const val GITHUB_REPOSITORY = "YOUR_WAVETUNE_REPOSITORY"
private const val RELEASE_APK_ASSET = "WaveTune.apk"

internal data class WaveTuneUpdate(val versionName: String, val downloadUrl: String)

internal fun fetchLatestWaveTuneUpdate(context: Context): WaveTuneUpdate? {
    if (GITHUB_OWNER.startsWith("YOUR_") || GITHUB_REPOSITORY.startsWith("YOUR_")) return null
    var connection: HttpURLConnection? = null
    return try {
        connection = (URL("https://api.github.com/repos/$GITHUB_OWNER/$GITHUB_REPOSITORY/releases/latest").openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 5000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }
        if (connection.responseCode !in 200..299) return null
        val body = connection.inputStream.bufferedReader().use { it.readText() }
        val release = JSONObject(body)
        if (release.optBoolean("draft", false) || release.optBoolean("prerelease", false)) return null
        val tag = release.optString("tag_name", "").removePrefix("v")
        val assets = release.optJSONArray("assets") ?: return null
        var apkUrl: String? = null
        for (i in 0 until assets.length()) {
            val asset = assets.optJSONObject(i) ?: continue
            if (asset.optString("name") == RELEASE_APK_ASSET) {
                apkUrl = asset.optString("browser_download_url").takeIf { it.startsWith("https://") }
                break
            }
        }
        val url = apkUrl ?: return null
        val currentVersion = if (Build.VERSION.SDK_INT >= 28) {
            context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode.toInt()
        } else {
            @Suppress("DEPRECATION") context.packageManager.getPackageInfo(context.packageName, 0).versionCode
        }
        val releaseCode = versionNameToCode(tag) ?: return null
        if (releaseCode > currentVersion) WaveTuneUpdate(tag, url) else null
    } catch (_: Exception) {
        // Update checks are optional; network/API issues must never block music playback.
        null
    } finally {
        connection?.disconnect()
    }
}

/** Maps semantic versions to the same versionCode convention used by the release workflow. */
private fun versionNameToCode(version: String): Int? {
    val match = Regex("^(\\d+)\\.(\\d+)\\.(\\d+)$").matchEntire(version) ?: return null
    val major = match.groupValues[1].toLongOrNull() ?: return null
    val minor = match.groupValues[2].toLongOrNull() ?: return null
    val patch = match.groupValues[3].toLongOrNull() ?: return null
    if (major > 200_000 || minor > 99 || patch > 99) return null
    return (major * 10_000 + minor * 100 + patch).takeIf { it <= Int.MAX_VALUE }?.toInt()
}
