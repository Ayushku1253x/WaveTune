package `in`.wavetune.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay

private val Bg = Color(0xFF070A12)
private val Panel = Color(0xFF101729)
private val Purple = Color(0xFF9D6BFF)
private val Cyan = Color(0xFF4AD7FF)
private val Muted = Color(0xFF9AA6C2)

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple, secondary = Cyan, background = Bg, surface = Panel
            )) {
                WaveTuneApp(
                    tracks = { loadTracks() },
                    player = player,
                    onOpenLocal = { uri ->
                        player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play()
                    }
                )
            }
        }
    }

    private fun loadTracks(): List<Track> {
        val result = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result += Track(
                    id, c.getString(titleCol) ?: "Unknown title",
                    c.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown artist",
                    ContentUris.withAppendedId(collection, id), c.getLong(durCol)
                )
            }
        }
        return result
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@Composable
private fun WaveTuneApp(
    tracks: () -> List<Track>,
    player: ExoPlayer,
    onOpenLocal: (Uri) -> Unit
) {
    var library by remember { mutableStateOf(emptyList<Track>()) }
    var selectedTab by remember { mutableStateOf("Home") }
    var current by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showAbout by remember { mutableStateOf(false) }
    var permissionRequested by remember { mutableStateOf(false) }
    var splashVisible by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(2600); splashVisible = false }
    val context = androidx.compose.ui.platform.LocalContext.current
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) library = tracks()
        permissionRequested = true
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            onOpenLocal(uri)
            current = Track(-1, uri.lastPathSegment?.substringAfterLast('/') ?: "Local audio file", "Local file", uri, 0L)
            isPlaying = true
        }
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED) library = tracks()
        else permissionLauncher.launch(audioPermission)
    }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    Box(Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B1020), contentColor = Color.White) {
                listOf("Home", "Library", "Search", "About").forEach { tab ->
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab; if (tab == "About") showAbout = true },
                        icon = {
                            Icon(when (tab) {
                                "Home" -> Icons.Default.Home
                                "Library" -> Icons.Default.LibraryMusic
                                "Search" -> Icons.Default.Search
                                else -> Icons.Default.Info
                            }, contentDescription = tab)
                        },
                        label = { Text(tab) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, indicatorColor = Color(0xFF202844))
                    )
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().background(Bg).padding(padding)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("WaveTune", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold,
                        color = Color.White)
                    Text("YOUR MUSIC • YOUR RULES", fontSize = 10.sp, color = Cyan, letterSpacing = 2.sp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Cyan))),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.GraphicEq, contentDescription = "WaveTune", tint = Color.White, modifier = Modifier.size(27.dp))
                }
            }
            when (selectedTab) {
                "Library" -> LibraryScreen(library, current, { track -> current = track; player.setMediaItem(MediaItem.fromUri(track.uri)); player.prepare(); player.play() })
                "Search" -> {
                    OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        placeholder = { Text("Search songs or artists…", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null) },
                        shape = RoundedCornerShape(18.dp), singleLine = true)
                    LibraryScreen(library.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, current,
                        { track -> current = track; player.setMediaItem(MediaItem.fromUri(track.uri)); player.prepare(); player.play() })
                }
                "About" -> AboutScreen()
                else -> HomeScreen(
                    count = library.size,
                    current = current,
                    isPlaying = isPlaying,
                    onRefresh = { library = tracks() },
                    onLibrary = { selectedTab = "Library" },
                    onLocal = { filePicker.launch(arrayOf("audio/*")) },
                    onPlay = {
                        if (current != null) {
                            if (player.isPlaying) player.pause() else player.play()
                        } else if (library.isNotEmpty()) {
                            current = library.first()
                            player.setMediaItem(MediaItem.fromUri(library.first().uri)); player.prepare(); player.play()
                        } else {
                            selectedTab = "Library"
                        }
                    }
                )
            }
            if (current != null) MiniPlayer(current!!, isPlaying) {
                if (player.isPlaying) player.pause() else player.play()
            }
        }
    }
        if (splashVisible) SplashScreen()
    }
}


@Composable
private fun SplashScreen() {
    val transition = rememberInfiniteTransition(label = "splash")
    val pulse by transition.animateFloat(
        initialValue = 0.88f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "logoPulse"
    )
    val fade by animateFloatAsState(targetValue = 1f, animationSpec = tween(900), label = "splashFade")
    Box(
        Modifier.fillMaxSize().background(
            Brush.linearGradient(listOf(Color(0xFF050711), Color(0xFF10152A), Color(0xFF160C2B)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = androidx.compose.ui.geometry.Offset(size.width * 0.5f, size.height * 0.39f)
            drawCircle(brush = Brush.radialGradient(
                colors = listOf(Color(0x553C7BFF), Color(0x223C7BFF), Color.Transparent),
                center = center, radius = size.minDimension * 0.62f
            ), radius = size.minDimension * 0.62f, center = center)
        }
        Column(
            Modifier.fillMaxWidth().padding(28.dp).graphicsLayer { alpha = fade },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier.size(112.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }
                    .clip(RoundedCornerShape(32.dp))
                    .background(Brush.linearGradient(listOf(Purple, Color(0xFF315DFF), Cyan))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.GraphicEq, contentDescription = "WaveTune logo",
                    tint = Color.White, modifier = Modifier.size(66.dp))
            }
            Spacer(Modifier.height(26.dp))
            Text("WaveTune", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold,
                color = Color.White, letterSpacing = (-1).sp)
            Text("YOUR MUSIC  •  YOUR RULES", fontSize = 11.sp, color = Cyan, letterSpacing = 2.sp)
            Spacer(Modifier.height(20.dp))
            Text("Created by Ayush !!", color = Color(0xFFD8B4FE), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(32.dp))
            CircularProgressIndicator(color = Cyan, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
            Spacer(Modifier.height(40.dp))
            Text("🇮🇳  Made with ♥ in India", color = Color(0xFFD4D9E8), fontSize = 13.sp)
        }
        Text(
            "MADE IN INDIA  🇮🇳  •  CREATED BY AYUSH !!",
            color = Color(0xFF7F8BA8), fontSize = 9.sp, letterSpacing = 1.3.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 26.dp)
        )
    }
}

@Composable
private fun HomeScreen(
    count: Int, current: Track?, isPlaying: Boolean, onRefresh: () -> Unit,
    onLibrary: () -> Unit, onLocal: () -> Unit, onPlay: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(
                Brush.linearGradient(listOf(Color(0xFF33205D), Color(0xFF112D49), Color(0xFF15182C)))
            ).padding(20.dp)) {
                Column {
                    Text("Your sound. Your space.", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("A clean home for the music on your device.", color = Color(0xFFD3D9F0))
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, null, tint = Cyan)
                        Text("  $count local tracks found", color = Cyan, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        item { Text("Quick access", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureTile("All songs", "On this device", Icons.Default.LibraryMusic, Modifier.weight(1f), onLibrary)
                FeatureTile("Open file", "Pick audio", Icons.Default.FolderOpen, Modifier.weight(1f), onLocal)
            }
        }
        item {
            FeatureTile("Refresh library", "Rescan device audio", Icons.Default.Refresh, Modifier.fillMaxWidth(), onRefresh)
        }
        item { Text("Now playing", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(18.dp)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(62.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Purple, Color(0xFF253E78)))),
                            contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(34.dp)) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(current?.title ?: "Pick a song to begin", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(current?.artist ?: "Your offline library awaits", color = Muted, fontSize = 13.sp)
                        }
                        IconButton(onClick = onPlay) { Icon(if (isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle, null, tint = Cyan, modifier = Modifier.size(38.dp)) }
                    }
                    Spacer(Modifier.height(14.dp))
                    AnimatedWave()
                }
            }
        }
        item {
            Text("Made in India 🇮🇳  •  Created by Ayush !!", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
        }
    }
}

@Composable
private fun FeatureTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(20.dp)).background(Panel).clickable { onClick() }.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF202747)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Cyan)
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun LibraryScreen(tracks: List<Track>, current: Track?, onSelect: (Track) -> Unit) {
    if (tracks.isEmpty()) {
        Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.LibraryMusic, null, tint = Purple, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(12.dp))
            Text("No local tracks found yet", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Allow audio access, add music to your device, then refresh.", color = Muted)
        }
    } else {
        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
            itemsIndexed(tracks, key = { _, track -> track.id }) { _, track ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onSelect(track) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Purple, Color(0xFF263C65)))),
                        contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    if (current?.id == track.id) Icon(Icons.Default.GraphicEq, null, tint = Cyan)
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(track: Track, isPlaying: Boolean, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp))
        .background(Color(0xFF171F34)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.MusicNote, null, tint = Purple)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(track.artist, color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onToggle) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Cyan) }
    }
}

@Composable
private fun AnimatedWave() {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "phase")
    Canvas(Modifier.fillMaxWidth().height(48.dp)) {
        val bars = 54
        val gap = 3.dp.toPx()
        val barWidth = (size.width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val wave = kotlin.math.abs(kotlin.math.sin(i * 0.36 + phase * 5.8)).toFloat()
            val h = size.height * (0.16f + wave * (0.25f + ((i % 7) / 10f)))
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Cyan, Purple)),
                topLeft = androidx.compose.ui.geometry.Offset(i * (barWidth + gap), (size.height - h) / 2),
                size = androidx.compose.ui.geometry.Size(barWidth, h),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth, barWidth)
            )
        }
    }
}

@Composable
private fun AboutScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("About WaveTune", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(20.dp)) {
            Column {
                Text("🎵  WaveTune", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Version 1.0.0 • Made in India 🇮🇳", color = Cyan, fontSize = 12.sp)
                Spacer(Modifier.height(16.dp))
                Text("Created by Ayush !!", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("I’m Ayush, a student at IIEST. I made WaveTune as a fun project to explore Android development and create a clean, fast, and welcoming home for music already available on your device.", color = Color(0xFFD0D7EB), lineHeight = 22.sp)
                Spacer(Modifier.height(12.dp))
                Text("Music should feel personal. WaveTune focuses on local playback, a minimal interface, and a little visual energy — without locking core features behind a paywall.", color = Color(0xFFD0D7EB), lineHeight = 22.sp)
                Spacer(Modifier.height(12.dp))
                Text("Support WaveTune", color = Cyan, fontWeight = FontWeight.Bold)
                Text("If you enjoy the app, you can support future updates using any UPI app.", color = Muted, lineHeight = 20.sp)
                Spacer(Modifier.height(10.dp))
                Image(
                    painter = painterResource(id = R.drawable.support_qr),
                    contentDescription = "Ayush UPI payment QR code",
                    modifier = Modifier.fillMaxWidth().heightIn(max = 340.dp).clip(RoundedCornerShape(18.dp))
                )
                Spacer(Modifier.height(6.dp))
                Text("UPI ID: ayushku92sk@okicici", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Scan to pay with any UPI app. Please verify the recipient before sending money.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
        }
        Text("Privacy-first note: this starter reads local audio only after Android permission is granted. It does not scrape or download tracks from Spotify or other services.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}
