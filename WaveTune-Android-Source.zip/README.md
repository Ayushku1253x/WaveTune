# WaveTune 🎧

**Your Music • Your Rules** — a dark, minimal Android music player starter by Ayush.

## Included in this starter
- Jetpack Compose UI with dark indigo / violet / cyan styling
- Reads the device's indexed music library after Android audio permission
- Plays local tracks through AndroidX Media3 ExoPlayer
- Android document picker for a user-selected audio file
- Search across local track title and artist
- Animated waveform visualizer (UI animation, not yet tied to decoded audio amplitude)
- Mini player, library list, About screen, Made in India branding
- About & Support screen includes the user-provided UPI QR and UPI ID
- Starter project structure ready to push to GitHub

## Supported formats
Actual format support depends on Android's Media3/OS decoders and the codec in the file. Commonly supported formats include MP3, AAC/M4A, Ogg Vorbis, WAV, and FLAC; Opus and other variants can vary by device/container. Do not promise every codec until tested on target devices.

## Spotify and other streaming services
WaveTune does **not** extract, record, download, or bypass DRM on Spotify, YouTube Music, or other third-party services. Android apps are sandboxed; another app's private cache/downloads are not a public music library. Users can play files they own or have lawful access to, and the app can later add ordinary deep links to open official streaming apps. Official playback integration requires each service's approved SDK/API and applicable account/terms.

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Run on an Android 8.0+ device/emulator.
5. Test local audio permissions, file picker, and codecs on real devices.
6. For a release: **Build > Generate Signed Bundle / APK**.

The project uses JDK 17 and Gradle via Android Studio. A Gradle wrapper is not included in this source archive; Android Studio can generate one or you can run `gradle wrapper` with a compatible Gradle installation.

## GitHub release checklist
- Replace package/application ID if desired.
- Add launcher icon, privacy policy, license, screenshots, and changelog.
- Test Android 13+ `READ_MEDIA_AUDIO` and Android 12-and-below storage permission paths.
- Add automated tests and crash reporting only with a transparent privacy policy.
- The supplied UPI QR image and UPI ID are included in the Support screen. Verify the recipient and scan behavior before publishing; consider whether you want this payment information public in a public repository.
- Build and test a signed APK/AAB before creating a GitHub Release.

## Roadmap
- Queue and background playback service / media notification
- Playback seek bar and previous/next controls
- Playlists persisted with Room
- Album art extraction and metadata cleanup
- Equalizer via Android audio effects where supported
- Lyrics from licensed/provider APIs only
- Audio waveform sourced from playback audio session
- Accessibility, tablet layout, unit/UI tests

## License
Choose a license before publishing (for example, MIT if that matches your intent and dependency obligations).


## Important feature status
This is a starter, not a finished commercial-grade player. The waveform is a visual animation, not measured audio amplitude. A true equalizer, persistent playlists, background media service, playback seek/queue controls, save/export flow, adaptive themes, and service integrations still need implementation and device testing. Audio quality labels such as 320 kbps must not imply upscaling: a player cannot create missing source quality.


## Beginner-friendly GitHub APK build (no local unzip)
You can let GitHub Actions unpack the source ZIP and build the APK in the cloud.

1. Create a GitHub repository.
2. Upload this project's ZIP as a single file named `WaveTune-Android-Source.zip`.
3. In GitHub, choose **Add file → Create new file** and enter `.github/workflows/build.yml`.
4. Paste the contents of the separately supplied `WaveTune-build.yml`, then commit it.
5. Open **Actions → Build WaveTune APK → Run workflow**.
6. When the run finishes, open the run and download the `WaveTune-debug-apk` artifact. GitHub provides it as a ZIP containing `app-debug.apk`; Android installation requires downloading that artifact and extracting the APK from it.
7. This is a debug APK for testing, not a signed production release. Do not share it as a verified release until tested.

GitHub requires the workflow YAML to exist at `.github/workflows/build.yml` in the repository root. Uploading a ZIP alone does not activate workflows; the one-time workflow-file step above is required.
