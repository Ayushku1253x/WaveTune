# WaveTune Android — Beginner Setup (Hindi)

यह ZIP WaveTune का पूरा Android source project है। इसमें मौजूदा app code, debug build workflow, optional update checker और signed-release workflow शामिल हैं। ZIP की integrity जाँची गई है; Android compilation/device testing इस environment में नहीं हुई है।

## ZIP में क्या है?
- `app/` — Android app source code और resources
- `.github/workflows/build.yml` — GitHub Actions से debug APK बनाने का workflow
- `.github/workflows/release.yml` — signed APK बनाकर GitHub Release में प्रकाशित करने का workflow
- `app/src/main/java/in/wavetune/player/UpdateChecker.kt` — GitHub Releases पर नया version check करता है

## सबसे आसान GitHub setup (iPad/Safari से)

### A. Repository में ये दो चीजें upload करें
1. इस ZIP को repository के **root** में exact नाम `WaveTune-Android-Source.zip` से upload करें। ZIP के अंदर के files को अलग-अलग extract करके upload करने की जरूरत नहीं है।
2. इस ZIP के अंदर मौजूद `.github/workflows/release.yml` को अलग से repository में इस path पर रखें: `.github/workflows/release.yml`। GitHub website में repository खोलें → **Add file → Create new file** → filename में `.github/workflows/release.yml` लिखें → ZIP में मौजूद release workflow का पूरा text paste करें → **Commit changes**। (या ZIP extract करके file upload करें, यदि आपके device/browser में extraction सुविधा है।)
3. ZIP में `build.yml` भी मौजूद है; सामान्य debug APK workflow के लिए repository में `.github/workflows/build.yml` भी होना चाहिए। यदि यह file पहले से है, उसे बदलने की जरूरत नहीं।

> GitHub Actions workflow ZIP के अंदर मौजूद होने भर से चालू नहीं होता। Workflow चलाने के लिए उसकी `.github/workflows/...yml` file repository में अलग से commit होनी चाहिए।

### B. Update checker में अपना GitHub repository भरें
`app/src/main/java/in/wavetune/player/UpdateChecker.kt` में ये दो lines हैं:

```kotlin
private const val GITHUB_OWNER = "YOUR_GITHUB_USERNAME"
private const val GITHUB_REPOSITORY = "YOUR_WAVETUNE_REPOSITORY"
```

इन्हें अपने GitHub username और repository name से बदलें। उदाहरण: username `ayush123`, repository `WaveTune` हो तो दोनों values उसी अनुसार भरें। Repository **public** होनी चाहिए ताकि app बिना login के GitHub Releases पढ़ सके। बदलाव के बाद `WaveTune-Android-Source.zip` को फिर से बनाकर repository में replace करें।

## C. पहला debug APK बनाना
1. GitHub repository → **Actions** खोलें।
2. **Build WaveTune APK** चुनें → **Run workflow** दबाएँ।
3. हरे check mark का इंतजार करें।
4. सफल run खोलें → नीचे **Artifacts** में `WaveTune-debug-apk` डाउनलोड करें। ZIP के अंदर APK मिलेगा।

## D. Optional update (signed release) setup — एक बार जरूरी
Android पुराने app के ऊपर update तभी install करता है जब **application ID, signing certificate वही हों और नया versionCode बड़ा हो**। Release workflow को एक स्थायी signing key चाहिए। इसे हर release पर बदलना नहीं है।

GitHub repository → **Settings → Secrets and variables → Actions → New repository secret** में ये चार secrets बनाएँ:

- `WAVETUNE_KEYSTORE_BASE64` — आपकी `.jks` keystore file का Base64 text
- `WAVETUNE_KEYSTORE_PASSWORD` — keystore password
- `WAVETUNE_KEY_ALIAS` — key alias
- `WAVETUNE_KEY_PASSWORD` — key password

**ध्यान दें:** यह ZIP आपके निजी signing key/password नहीं बना सकता या जान नहीं सकता। इन्हें सुरक्षित रूप से एक बार बनाकर GitHub Secrets में डालना जरूरी है। Keystore की सुरक्षित backup copy रखें; इसे GitHub repo में कभी upload/commit न करें।

## E. नया update publish करना
1. सुनिश्चित करें कि `UpdateChecker.kt` में सही public repo username/name है और GitHub Secrets सेट हैं।
2. GitHub → **Actions → Publish WaveTune Update → Run workflow** खोलें।
3. version में `1.0.1` जैसे नया version भरें (हर release में version बढ़ाएँ; current source `1.0.0` है)।
4. **Run workflow** दबाएँ। सफल होने पर GitHub Release बनेगी और `WaveTune.apk` asset प्रकाशित होगा।
5. Installed app खुलने पर वह GitHub Releases चेक करेगा। नया version मिले तो **Update now / Later** prompt दिखाएगा। `Update now` browser/download link खोलता है; Android user से install confirmation माँगता है। `Later` पर मौजूदा app चलता रहता है।

## बहुत जरूरी: पहले से install हुए debug APK के बारे में
अगर फोन में पहले से GitHub Actions का debug APK है, तो वह debug key से signed होगा। पहली बार स्थायी release key वाले APK पर जाने के लिए **एक बार uninstall की जरूरत पड़ सकती है**, और इससे local app data मिट सकता है। उसके बाद उसी स्थायी key से बने अगले releases सामान्यतः uninstall किए बिना update हो सकते हैं। यदि data बचाना जरूरी है, तो पहले spare/test phone पर आजमाएँ।

## ईमानदार सीमाएँ
- Update prompt app खुलने पर online GitHub Releases check करता है; यह हर समय background push notification नहीं है। Internet/API उपलब्ध न हो तो music playback block नहीं होगा।
- `Update now` Android की system installer confirmation को bypass नहीं करता और app खुद को चुपचाप install नहीं कर सकता।
- नई code/features के लिए नया APK release जरूरी है। सिर्फ GitHub पर code edit करने से पहले से installed apps अपने-आप update नहीं होते।
- इस source ZIP और workflows की Android build/device update test यहाँ नहीं की गई। पहले GitHub Actions logs जाँचें और test device पर update verify करें।
