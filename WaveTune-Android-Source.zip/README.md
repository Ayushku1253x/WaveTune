# WaveTune Android

A dark, neon-accented local music player built with Kotlin and Jetpack Compose.

## Included in this source
- Local audio library and file picker
- Home screen, search, favorites, queue, and full-screen now-playing UI
- Playback controls: play/pause, previous/next, seeking, shuffle, repeat, 10-second skip
- Animated waveform-style visualizer UI
- Audio Lab with playback speed/pitch and device-dependent system equalizer controls
- Audio editor/trim UI and export code paths where supported
- Sleep timer UI, optional haptic pulse, About/Support screen and supplied support QR
- Custom WaveTune adaptive launcher icon
- GitHub Actions workflow to build a debug APK from this ZIP

## Build with GitHub Actions
Upload this archive to the repository root with the exact filename `WaveTune-Android-Source.zip`. Keep the workflow file at `.github/workflows/build.yml` in the repository's default branch. Open Actions and run `Build WaveTune APK`.

## Important limitations
This is a local-audio player, not a licensed streaming catalog. Visualizer bars are currently animated UI rather than measured audio-spectrum data. Bass-synchronized haptics, true reverse playback, robust background playback/media notification, and seamless self-updating of already-installed APKs require additional implementation and device testing; do not assume they are active just because a UI control exists. A new GitHub build does not automatically update APKs already installed on users' phones.
