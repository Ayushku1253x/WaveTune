package `in`.wavetune.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.os.ParcelFileDescriptor
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.sin

private val Bg = Color(0xFF070914)
private val Panel = Color(0xFF11172A)
private val Panel2 = Color(0xFF171F37)
private val Purple = Color(0xFFB05CFF)
private val Cyan = Color(0xFF55E5FF)
private val Pink = Color(0xFFFF5CA8)
private val Muted = Color(0xFF9CA8C5)
private val White = Color(0xFFF8F9FF)

private data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Cyan, background = Bg, surface = Panel)) {
                WaveTuneApp(
                    player = player,
                    loadTracks = { loadTracks() },
                    onVibrate = { millis ->
                        try {
                            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
                            } else {
                                @Suppress("DEPRECATION")
                                getSystemService(VIBRATOR_SERVICE) as Vibrator
                            }
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator.vibrate(VibrationEffect.createOneShot(millis, 45))
                            else @Suppress("DEPRECATION") vibrator.vibrate(millis)
                        } catch (_: Exception) { }
                    }
                )
            }
        }
    }

    private fun loadTracks(): List<Track> {
        val result = mutableListOf<Track>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                result += Track(
                    id = id,
                    title = cursor.getString(titleCol)?.takeIf { it.isNotBlank() } ?: "Unknown title",
                    artist = cursor.getString(artistCol)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist",
                    uri = ContentUris.withAppendedId(collection, id),
                    duration = cursor.getLong(durationCol)
                )
            }
        }
        return result
    }

    override fun onDestroy() {
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

@Composable
private fun WaveTuneApp(player: ExoPlayer, loadTracks: () -> List<Track>, onVibrate: (Long) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var library by remember { mutableStateOf(emptyList<Track>()) }
    var queue by remember { mutableStateOf(emptyList<Track>()) }
    var current by remember { mutableStateOf<Track?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Home") }
    var query by remember { mutableStateOf("") }
    var playerOpen by remember { mutableStateOf(false) }
    var labOpen by remember { mutableStateOf(false) }
    var editorOpen by remember { mutableStateOf(false) }
    var queueOpen by remember { mutableStateOf(false) }
    var aboutOpen by remember { mutableStateOf(false) }
    var splashVisible by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var shuffle by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var speed by remember { mutableFloatStateOf(1f) }
    var pitch by remember { mutableFloatStateOf(1f) }
    var favorites by remember { mutableStateOf(setOf<Long>()) }
    var sleepMinutes by remember { mutableIntStateOf(0) }
    var hapticPulse by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }

    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) library = loadTracks() else statusMessage = "Allow music access to show your local library."
    }
    val openDocument = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val track = Track(-uri.hashCode().toLong(), uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Imported audio", "Local file", uri, 0L)
            queue = listOf(track)
            current = track
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.play()
            playerOpen = true
        }
    }

    LaunchedEffect(Unit) {
        delay(1300)
        splashVisible = false
        if (ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED) library = loadTracks()
        else permissionLauncher.launch(audioPermission)
    }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val index = player.currentMediaItemIndex
                if (index in queue.indices) current = queue[index]
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                duration = player.duration.coerceAtLeast(0L)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player, playerOpen) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(350)
        }
    }
    LaunchedEffect(sleepMinutes) {
        val selected = sleepMinutes
        if (selected > 0) {
            delay(selected * 60_000L)
            player.pause()
            sleepMinutes = 0
            statusMessage = "Sleep timer finished. Playback paused."
        }
    }
    LaunchedEffect(hapticPulse, isPlaying) {
        while (hapticPulse && isPlaying) {
            delay(650)
            onVibrate(12L)
        }
    }

    fun playTrack(track: Track, source: List<Track> = library) {
        val list = source.ifEmpty { listOf(track) }
        queue = list
        val index = list.indexOfFirst { it.uri == track.uri }.coerceAtLeast(0)
        current = track
        player.setMediaItems(list.map { MediaItem.fromUri(it.uri) }, index, 0L)
        player.prepare()
        player.play()
        playerOpen = true
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF0B1020), contentColor = White) {
                    listOf("Home", "Library", "Search", "Audio Lab", "About").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab; if (tab == "Audio Lab") labOpen = true; if (tab == "About") aboutOpen = true },
                            icon = {
                                Icon(when (tab) {
                                    "Home" -> Icons.Default.Home
                                    "Library" -> Icons.Default.LibraryMusic
                                    "Search" -> Icons.Default.Search
                                    "Audio Lab" -> Icons.Default.GraphicEq
                                    else -> Icons.Default.Info
                                }, contentDescription = tab)
                            },
                            label = { Text(tab, fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, indicatorColor = Color(0xFF252447), selectedTextColor = Cyan, unselectedTextColor = Muted)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("WaveTune", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = White, letterSpacing = (-0.8).sp)
                        Text("FEEL EVERY BEAT", fontSize = 10.sp, color = Cyan, letterSpacing = 2.5.sp)
                    }
                    IconButton(onClick = { labOpen = true }) {
                        Box(Modifier.size(44.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Purple, Color(0xFF3A55C8), Cyan))), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.GraphicEq, null, tint = White, modifier = Modifier.size(27.dp))
                        }
                    }
                }
                when (selectedTab) {
                    "Library" -> LibraryScreen(library, current, favorites, onPlay = { playTrack(it) }, onFavorite = { t -> favorites = if (t.id in favorites) favorites - t.id else favorites + t.id }, onRefresh = { library = loadTracks() })
                    "Search" -> Column {
                        OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), placeholder = { Text("Songs, artists, albums…", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(18.dp), singleLine = true)
                        LibraryScreen(library.filter { it.title.contains(query, true) || it.artist.contains(query, true) }, current, favorites, onPlay = { playTrack(it, library.filter { t -> t.title.contains(query, true) || t.artist.contains(query, true) }) }, onFavorite = { t -> favorites = if (t.id in favorites) favorites - t.id else favorites + t.id }, onRefresh = { library = loadTracks() })
                    }
                    "Audio Lab" -> HomeScreen(library = library, current = current, isPlaying = isPlaying, onRefresh = { library = loadTracks() }, onLibrary = { selectedTab = "Library" }, onOpenFile = { openDocument.launch(arrayOf("audio/*")) }, onPlay = { if (current != null) { if (isPlaying) player.pause() else player.play(); playerOpen = true } else if (library.isNotEmpty()) playTrack(library.first()) }, onPlayTrack = { playTrack(it) }, onLab = { labOpen = true }, onEditor = { editorOpen = true })
                    else -> HomeScreen(library = library, current = current, isPlaying = isPlaying, onRefresh = { library = loadTracks() }, onLibrary = { selectedTab = "Library" }, onOpenFile = { openDocument.launch(arrayOf("audio/*")) }, onPlay = { if (current != null) { if (isPlaying) player.pause() else player.play(); playerOpen = true } else if (library.isNotEmpty()) playTrack(library.first()) }, onPlayTrack = { playTrack(it) }, onLab = { labOpen = true }, onEditor = { editorOpen = true })
                }
                if (current != null) {
                    MiniPlayer(track = current!!, isPlaying = isPlaying, position = position, duration = duration,
                        onOpen = { playerOpen = true }, onToggle = { if (isPlaying) player.pause() else player.play() },
                        onNext = { player.seekToNextMediaItem() })
                }
            }
        }

        AnimatedVisibility(visible = splashVisible) { SplashScreen() }
        if (playerOpen && current != null) {
            Dialog(onDismissRequest = { playerOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
                PlayerScreen(
                    track = current!!, player = player, isPlaying = isPlaying, position = position, duration = duration,
                    shuffle = shuffle, repeatMode = repeatMode, favorite = current!!.id in favorites,
                    onClose = { playerOpen = false }, onToggle = { if (isPlaying) player.pause() else player.play() },
                    onSeek = { player.seekTo(it) }, onBack10 = { player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L)) },
                    onForward10 = { player.seekTo((player.currentPosition + 10_000L).coerceAtMost(player.duration.coerceAtLeast(0L))) },
                    onPrevious = { if (player.currentPosition > 3_000L) player.seekTo(0L) else player.seekToPreviousMediaItem() },
                    onNext = { player.seekToNextMediaItem() }, onShuffle = { shuffle = !shuffle; player.shuffleModeEnabled = shuffle },
                    onRepeat = { repeatMode = when (repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }; player.repeatMode = repeatMode },
                    onFavorite = { favorites = if (current!!.id in favorites) favorites - current!!.id else favorites + current!!.id },
                    onQueue = { queueOpen = true }, onLab = { labOpen = true }, onEditor = { editorOpen = true },
                    speed = speed, onSpeed = { speed = it; player.playbackParameters = PlaybackParameters(speed, pitch) },
                    pitch = pitch, onPitch = { pitch = it; player.playbackParameters = PlaybackParameters(speed, pitch) },
                    hapticPulse = hapticPulse, onHaptic = { hapticPulse = !hapticPulse }, sleepMinutes = sleepMinutes,
                    onSleep = { sleepMinutes = it }, onVibrate = onVibrate
                )
            }
        }
        if (labOpen) Dialog(onDismissRequest = { labOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            AudioLabScreen(player = player, speed = speed, pitch = pitch, onSpeed = { speed = it; player.playbackParameters = PlaybackParameters(speed, pitch) }, onPitch = { pitch = it; player.playbackParameters = PlaybackParameters(speed, pitch) }, onClose = { labOpen = false })
        }
        if (editorOpen && current != null) Dialog(onDismissRequest = { editorOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            AudioEditorScreen(track = current!!, player = player, position = position, duration = duration, onClose = { editorOpen = false }, onMessage = { statusMessage = it })
        }
        if (queueOpen) Dialog(onDismissRequest = { queueOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            QueueScreen(queue = queue, current = current, onClose = { queueOpen = false }, onPlay = { track -> queueOpen = false; playTrack(track, queue) })
        }
        if (aboutOpen) Dialog(onDismissRequest = { aboutOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            AboutScreen(onClose = { aboutOpen = false })
        }
        if (statusMessage.isNotBlank()) AlertDialog(onDismissRequest = { statusMessage = "" }, confirmButton = { TextButton(onClick = { statusMessage = "" }) { Text("OK") } }, title = { Text("WaveTune") }, text = { Text(statusMessage) }, containerColor = Panel, titleContentColor = White, textContentColor = Muted)
    }
}

@Composable
private fun SplashScreen() {
    val transition = rememberInfiniteTransition(label = "splash")
    val pulse by transition.animateFloat(0.9f, 1.08f, infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF060713), Color(0xFF18102F), Color(0xFF061D2A)))), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(124.dp).graphicsLayer { scaleX = pulse; scaleY = pulse }.clip(RoundedCornerShape(38.dp)).background(Brush.linearGradient(listOf(Purple, Color(0xFF3B55E8), Cyan))), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.GraphicEq, null, tint = White, modifier = Modifier.size(70.dp))
            }
            Spacer(Modifier.height(25.dp))
            Text("WaveTune", fontSize = 39.sp, fontWeight = FontWeight.Black, color = White, letterSpacing = (-1.2).sp)
            Text("FEEL EVERY BEAT", fontSize = 11.sp, color = Cyan, letterSpacing = 3.sp)
            Spacer(Modifier.height(20.dp))
            Text("Created by Ayush !!", fontSize = 16.sp, color = Color(0xFFE4C5FF), fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(28.dp))
            CircularProgressIndicator(color = Cyan, strokeWidth = 2.dp, modifier = Modifier.size(23.dp))
            Spacer(Modifier.height(42.dp))
            Text("🇮🇳  MADE WITH LOVE IN INDIA", color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp)
        }
    }
}

@Composable
private fun HomeScreen(
    library: List<Track>, current: Track?, isPlaying: Boolean,
    onRefresh: () -> Unit, onLibrary: () -> Unit, onOpenFile: () -> Unit,
    onPlay: () -> Unit, onPlayTrack: (Track) -> Unit, onLab: () -> Unit, onEditor: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 4.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Listen Now", color = White, fontSize = 34.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.2).sp)
                    Text("YOUR MUSIC. YOUR MOMENT.", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Box(Modifier.size(43.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF1578D4), Color(0xFF6946D8)))), contentAlignment = Alignment.Center) {
                    Text("A", color = White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Recents", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onLibrary) { Text("See all", color = Color(0xFF68AFFF)) }
            }
            if (library.isEmpty()) {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).clickable { onOpenFile() }.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AlbumGlyph(56); Spacer(Modifier.width(13.dp)); Column(Modifier.weight(1f)) {
                            Text("Add your first song", color = White, fontWeight = FontWeight.Bold)
                            Text("Choose audio from your phone to start listening.", color = Muted, fontSize = 12.sp)
                        }; Icon(Icons.Default.Add, null, tint = Cyan)
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    library.take(6).forEachIndexed { index, track ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(if (current?.uri == track.uri) Color(0xFF171923) else Color.Transparent).clickable { onPlayTrack(track) }.padding(vertical = 7.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumGlyph(58); Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = if (current?.uri == track.uri) Color(0xFFFF668D) else White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(track.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { onPlayTrack(track) }) { Icon(Icons.Default.MoreVert, null, tint = Muted) }
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Albums & singles", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = Muted) }
            }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                itemsIndexed(library.take(10)) { _, track ->
                    Column(Modifier.width(156.dp).clickable { onPlayTrack(track) }) {
                        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Color(0xFF163E5A), Color(0xFF6B246C), Color(0xFFDA674D)))), contentAlignment = Alignment.Center) {
                            AlbumGlyph(92)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(track.title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                item {
                    Column(Modifier.width(156.dp).clickable { onOpenFile() }) {
                        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(18.dp)).background(Panel2), contentAlignment = Alignment.Center) { Icon(Icons.Default.FolderOpen, null, tint = Cyan, modifier = Modifier.size(44.dp)) }
                        Spacer(Modifier.height(8.dp)); Text("Import audio", color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text("From your device", color = Muted, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Text("Make it yours", color = White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StudioTile("Equalizer", "Bass • vocal • custom", Icons.Default.GraphicEq, Modifier.weight(1f), onLab)
                StudioTile("Audio editor", "Trim & export", Icons.Default.ContentCut, Modifier.weight(1f), onEditor)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StudioTile("Open audio", "Import a file", Icons.Default.FolderOpen, Modifier.weight(1f), onOpenFile)
                StudioTile("All songs", "${library.size} local tracks", Icons.Default.LibraryMusic, Modifier.weight(1f), onLibrary)
            }
        }
        item {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF171126), Color(0xFF0C2531)))).clickable { onPlay() }.padding(16.dp)) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AlbumGlyph(54); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) {
                            Text("NOW PLAYING", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                            Text(current?.title ?: "Your next favourite", color = White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(current?.artist ?: "Pick a track from Recents", color = Muted, fontSize = 12.sp)
                        }
                        Icon(if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled, null, tint = White, modifier = Modifier.size(38.dp))
                    }
                    Spacer(Modifier.height(12.dp)); AnimatedWave(isPlaying = isPlaying)
                }
            }
        }
        item { Text("Created by Ayush !!     Made with ❤️ in India 🇮🇳", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 6.dp)) }
    }
}

@Composable
private fun MoodTile(title: String, subtitle: String, colors: List<Color>, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(20.dp)).background(Panel).clickable { onClick() }.padding(10.dp)) {
        Box(Modifier.fillMaxWidth().height(76.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(colors)), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(10.dp)) { for (i in 0..24) { val h = size.height * (0.15f + abs(sin(i * 0.7)).toFloat() * 0.75f); drawRoundRect(Color.White.copy(alpha = 0.8f), androidx.compose.ui.geometry.Offset(i * size.width / 25f, (size.height - h) / 2), androidx.compose.ui.geometry.Size(size.width / 40f, h), cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f)) } }
        }
        Spacer(Modifier.height(8.dp)); Text(title, color = White, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp); Text(subtitle, color = Muted, fontSize = 9.sp)
    }
}

@Composable
private fun StudioTile(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(20.dp)).background(Panel).clickable { onClick() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF302253), Color(0xFF15364B)))), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Cyan) }
        Spacer(Modifier.width(10.dp)); Column { Text(title, color = White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text(subtitle, color = Muted, fontSize = 10.sp) }
    }
}

@Composable
private fun AlbumGlyph(size: Int) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Purple, Color(0xFF334BD3), Cyan))), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            drawCircle(Color.White.copy(alpha = 0.9f), radius = minOf(this.size.width, this.size.height) * 0.27f, style = Stroke(width = 2.dp.toPx()))
            for (i in 0..8) {
                val h = this.size.height * (0.15f + abs(sin(i * 1.3)).toFloat() * 0.55f)
                drawRoundRect(Color.White, androidx.compose.ui.geometry.Offset(this.size.width * 0.16f + i * this.size.width * 0.085f, (this.size.height - h) / 2), androidx.compose.ui.geometry.Size(this.size.width * 0.045f, h), cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f))
            }
        }
    }
}

@Composable
private fun LibraryScreen(tracks: List<Track>, current: Track?, favorites: Set<Long>, onPlay: (Track) -> Unit, onFavorite: (Track) -> Unit, onRefresh: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text("Your library", color = White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold); Text("${tracks.size} tracks • stored on your device", color = Muted, fontSize = 11.sp) }
            IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = Cyan) }
        }
        if (tracks.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.LibraryMusic, null, tint = Purple, modifier = Modifier.size(52.dp)); Spacer(Modifier.height(12.dp)); Text("No music found yet", color = White, fontWeight = FontWeight.Bold); Text("Allow audio access, add music, then refresh.", color = Muted)
            }
        } else LazyColumn(contentPadding = PaddingValues(horizontal = 13.dp, vertical = 6.dp)) {
            itemsIndexed(tracks, key = { _, track -> track.id }) { _, track ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp)).clickable { onPlay(track) }.padding(horizontal = 8.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    AlbumGlyph(47); Spacer(Modifier.width(11.dp))
                    Column(Modifier.weight(1f)) { Text(track.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    if (current?.uri == track.uri) Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.padding(end = 4.dp))
                    IconButton(onClick = { onFavorite(track) }) { Icon(if (track.id in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (track.id in favorites) Pink else Muted) }
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(track: Track, isPlaying: Boolean, position: Long, duration: Long, onOpen: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp).clip(RoundedCornerShape(20.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF1D1837), Color(0xFF102B3B)))).clickable { onOpen() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlbumGlyph(43); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(track.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 10.sp, maxLines = 1) }
            IconButton(onClick = onToggle) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Cyan) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White) }
        }
        LinearProgressIndicator(progress = { if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f }, modifier = Modifier.fillMaxWidth().height(2.dp).clip(CircleShape), color = Cyan, trackColor = Color.White.copy(alpha = 0.13f))
    }
}

@Composable
private fun PlayerScreen(
    track: Track, player: ExoPlayer, isPlaying: Boolean, position: Long, duration: Long,
    shuffle: Boolean, repeatMode: Int, favorite: Boolean, onClose: () -> Unit, onToggle: () -> Unit,
    onSeek: (Long) -> Unit, onBack10: () -> Unit, onForward10: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit, onFavorite: () -> Unit, onQueue: () -> Unit, onLab: () -> Unit, onEditor: () -> Unit,
    speed: Float, onSpeed: (Float) -> Unit, pitch: Float, onPitch: (Float) -> Unit,
    hapticPulse: Boolean, onHaptic: () -> Unit, sleepMinutes: Int, onSleep: (Int) -> Unit, onVibrate: (Long) -> Unit
) {
    var showAdvanced by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF21133C), Bg, Color(0xFF061A29)))).padding(20.dp)) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) { Icon(Icons.Default.KeyboardArrowDown, null, tint = White, modifier = Modifier.size(32.dp)) }
                Spacer(Modifier.weight(1f)); Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("NOW PLAYING", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp); Text("LOCAL LIBRARY", color = Muted, fontSize = 9.sp) }; Spacer(Modifier.weight(1f))
                IconButton(onClick = onQueue) { Icon(Icons.Default.QueueMusic, null, tint = White) }
            }
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().aspectRatio(1f).padding(horizontal = 18.dp), contentAlignment = Alignment.Center) {
                val transition = rememberInfiniteTransition(label = "albumGlow")
                val rotation by transition.animateFloat(0f, 360f, infiniteRepeatable(tween(18000), RepeatMode.Restart), label = "rotation")
                Canvas(Modifier.fillMaxSize()) { drawCircle(brush = Brush.sweepGradient(listOf(Purple, Cyan, Pink, Purple)), style = Stroke(width = 3.dp.toPx())); drawCircle(Color.White.copy(alpha = 0.035f), radius = size.minDimension * 0.42f) }
                Box(Modifier.fillMaxSize(0.78f).graphicsLayer { rotationZ = if (isPlaying) rotation * 0.08f else 0f }.clip(RoundedCornerShape(40.dp)).background(Brush.linearGradient(listOf(Color(0xFF5A268A), Color(0xFF214C92), Color(0xFF087C8D)))), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize().padding(18.dp)) { for (i in 0..28) { val h = size.height * (0.08f + abs(sin(i * 0.43f + if (isPlaying) rotation / 30f else 0f)).toFloat() * 0.58f); drawRoundRect(Color.White.copy(alpha = 0.8f), androidx.compose.ui.geometry.Offset(i * size.width / 29f, (size.height - h) / 2), androidx.compose.ui.geometry.Size(size.width / 45f, h), cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f)) } }
                    Icon(Icons.Default.GraphicEq, null, tint = Color.White.copy(alpha = 0.75f), modifier = Modifier.size(80.dp))
                }
            }
            Spacer(Modifier.height(24.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(track.title, color = White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 14.sp) }
                IconButton(onClick = onFavorite) { Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Pink else White, modifier = Modifier.size(27.dp)) }
            }
            Spacer(Modifier.height(15.dp))
            Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f, onValueChange = { onSeek(it.toLong()) }, valueRange = 0f..duration.coerceAtLeast(1L).toFloat(), colors = SliderDefaults.colors(thumbColor = White, activeTrackColor = Purple, inactiveTrackColor = Color.White.copy(alpha = 0.17f)))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(formatTime(position), color = Muted, fontSize = 11.sp); Text("-${formatTime((duration - position).coerceAtLeast(0L))}", color = Muted, fontSize = 11.sp) }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onShuffle) { Icon(Icons.Default.Shuffle, null, tint = if (shuffle) Cyan else Muted) }
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = White, modifier = Modifier.size(34.dp)) }
                IconButton(onClick = onBack10) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Replay10, null, tint = White, modifier = Modifier.size(26.dp)); Text("10s", color = Muted, fontSize = 8.sp) } }
                Box(Modifier.size(72.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Color(0xFF5B4CE2)))).clickable { onToggle() }, contentAlignment = Alignment.Center) { Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(42.dp)) }
                IconButton(onClick = onForward10) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Forward10, null, tint = White, modifier = Modifier.size(26.dp)); Text("10s", color = Muted, fontSize = 8.sp) } }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = White, modifier = Modifier.size(34.dp)) }
                IconButton(onClick = onRepeat) { Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, null, tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Cyan) }
            }
            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                ActionPill("Audio Lab", Icons.Default.Tune, Modifier.weight(1f), onLab)
                ActionPill("Edit audio", Icons.Default.ContentCut, Modifier.weight(1f), onEditor)
                ActionPill("Queue", Icons.Default.QueueMusic, Modifier.weight(1f), onQueue)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionPill(if (hapticPulse) "Pulse ON" else "Haptic pulse", Icons.Default.Vibration, Modifier.weight(1f), onHaptic)
                ActionPill(if (sleepMinutes > 0) "Sleep ${sleepMinutes}m" else "Sleep timer", Icons.Default.Bedtime, Modifier.weight(1f)) { showAdvanced = !showAdvanced }
            }
            AnimatedVisibility(showAdvanced) {
                Column(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(20.dp)).background(Panel).padding(14.dp)) {
                    Text("Sleep timer", color = White, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(0, 15, 30, 45, 60).forEach { minutes -> FilterChip(selected = sleepMinutes == minutes, onClick = { onSleep(minutes) }, label = { Text(if (minutes == 0) "Off" else "${minutes}m") }) } }
                    Text("Haptic pulse is a timed experimental vibration while playing; it is not yet synchronized to detected bass.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("WaveTune • Feel every beat • Made in India 🇮🇳", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ActionPill(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(15.dp)).background(Panel2).clickable { onClick() }.padding(horizontal = 10.dp, vertical = 12.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Cyan, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(6.dp)); Text(label, color = White, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
private fun AudioLabScreen(player: ExoPlayer, speed: Float, pitch: Float, onSpeed: (Float) -> Unit, onPitch: (Float) -> Unit, onClose: () -> Unit) {
    val context = LocalContext.current
    val equalizer = remember(player.audioSessionId) { if (player.audioSessionId > 0) runCatching { android.media.audiofx.Equalizer(0, player.audioSessionId) }.getOrNull() else null }
    var eqEnabled by remember { mutableStateOf(false) }
    var revision by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("") }
    DisposableEffect(equalizer) { onDispose { runCatching { equalizer?.release() } } }
    Box(Modifier.fillMaxSize().background(Bg).padding(14.dp)) {
        Column(Modifier.fillMaxSize().clip(RoundedCornerShape(28.dp)).background(Panel).padding(18.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("AUDIO LAB", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp); Text("Shape your sound", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold) }; IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = White) } }
            Text("REAL-TIME PLAYBACK CONTROLS", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Equalizer", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Switch(checked = eqEnabled, onCheckedChange = { enabled -> eqEnabled = enabled; runCatching { equalizer?.enabled = enabled }; if (equalizer == null) message = "System equalizer is not available until audio starts on this device." }) }
            if (equalizer != null) {
                val bands = equalizer.numberOfBands.toInt()
                val range = equalizer.bandLevelRange
                for (i in 0 until bands) {
                    val centerFreq = runCatching { equalizer.getCenterFreq(i.toShort()) / 1000 }.getOrDefault(0)
                    val level = runCatching { equalizer.getBandLevel(i.toShort()).toInt() }.getOrDefault(0)
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(if (centerFreq >= 1000) "${centerFreq / 1000f} kHz" else "$centerFreq Hz", color = White, fontSize = 11.sp); Text("${level} dB", color = Cyan, fontSize = 10.sp) }
                        Slider(value = level.toFloat(), onValueChange = { v -> runCatching { equalizer.setBandLevel(i.toShort(), v.toInt().toShort()) }; revision++ }, valueRange = range[0].toFloat()..range[1].toFloat(), enabled = eqEnabled, colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Purple))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Flat", "Bass", "Vocal", "Dance").forEach { preset -> OutlinedButton(onClick = {
                        val count = equalizer.numberOfPresets.toInt()
                        val target = (0 until count).firstOrNull { equalizer.getPresetName(it.toShort()).toString().contains(preset, true) }
                        if (target != null) runCatching { equalizer.usePreset(target.toShort()); eqEnabled = true; equalizer.enabled = true; revision++ }
                        else message = "This phone does not provide a $preset equalizer preset. Adjust bands manually."
                    }) { Text(preset, fontSize = 10.sp) } }
                }
            } else {
                Text("Start playback to connect the device's system equalizer. Some phones do not expose an equalizer.", color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            }
            Spacer(Modifier.height(15.dp)); HorizontalDivider(color = Color.White.copy(alpha = 0.1f)); Spacer(Modifier.height(15.dp))
            Text("Playback speed", color = White, fontWeight = FontWeight.Bold); Text("${"%.2f".format(speed)}×", color = Cyan, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Slider(value = speed, onValueChange = onSpeed, valueRange = 0.5f..2f, steps = 14, colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Purple))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(0.75f, 1f, 1.25f, 1.5f).forEach { v -> FilterChip(selected = speed == v, onClick = { onSpeed(v) }, label = { Text("${v}×") }) } }
            Spacer(Modifier.height(12.dp)); Text("Pitch", color = White, fontWeight = FontWeight.Bold); Text("${"%.2f".format(pitch)}×", color = Cyan, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Slider(value = pitch, onValueChange = onPitch, valueRange = 0.75f..1.5f, steps = 14, colors = SliderDefaults.colors(thumbColor = Pink, activeTrackColor = Pink))
            Text("Pitch and speed controls change playback only; they do not rewrite or upscale the source file.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
            if (message.isNotBlank()) { Spacer(Modifier.height(10.dp)); Text(message, color = Color(0xFFFFD479), fontSize = 11.sp) }
            Spacer(Modifier.height(18.dp)); Button(onClick = onClose, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text("Done") }
        }
    }
}

@Composable
private fun AudioEditorScreen(track: Track, player: ExoPlayer, position: Long, duration: Long, onClose: () -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var startMs by remember(track.uri) { mutableLongStateOf(0L) }
    var endMs by remember(track.uri, duration) { mutableLongStateOf(if (duration > 0) duration else track.duration) }
    var exporting by remember { mutableStateOf(false) }
    var editorMessage by remember { mutableStateOf("Trim a section and export it as an M4A file. Codec support depends on the source audio.") }
    val createDocument = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { destination ->
        if (destination != null) {
            exporting = true
            scope.launch {
                val result = withContext(Dispatchers.IO) { trimAudioToM4a(context.contentResolver, track.uri, destination, startMs, endMs) }
                exporting = false
                editorMessage = result
                onMessage(result)
            }
        }
    }
    val total = (if (duration > 0) duration else track.duration).coerceAtLeast(1000L)
    endMs = endMs.coerceIn(1000L, total)
    startMs = startMs.coerceIn(0L, (endMs - 1000L).coerceAtLeast(0L))
    Box(Modifier.fillMaxSize().background(Bg).padding(14.dp)) {
        Column(Modifier.fillMaxSize().clip(RoundedCornerShape(28.dp)).background(Panel).padding(18.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("WAVETUNE STUDIO", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp); Text("Audio editor", color = White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold) }; IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = White) } }
            Text(track.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("Choose the section you want to keep", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(22.dp)); AnimatedWave(isPlaying = player.isPlaying)
            Text("IN POINT • ${formatTime(startMs)}", color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.Bold); Slider(value = startMs.toFloat(), onValueChange = { startMs = it.toLong().coerceAtMost(endMs - 1000L) }, valueRange = 0f..(total - 1000L).coerceAtLeast(1L).toFloat(), colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Purple))
            Text("OUT POINT • ${formatTime(endMs)}", color = Pink, fontSize = 12.sp, fontWeight = FontWeight.Bold); Slider(value = endMs.toFloat(), onValueChange = { endMs = it.toLong().coerceAtLeast(startMs + 1000L) }, valueRange = (startMs + 1000L).coerceAtMost(total).toFloat()..total.toFloat(), colors = SliderDefaults.colors(thumbColor = Pink, activeTrackColor = Pink))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { startMs = position.coerceIn(0L, (total - 1000L).coerceAtLeast(0L)) }) { Icon(Icons.Default.Flag, null); Text(" Set start") }
                OutlinedButton(onClick = { endMs = position.coerceIn(startMs + 1000L, total) }) { Icon(Icons.Default.Flag, null); Text(" Set end") }
            }
            Spacer(Modifier.height(14.dp)); Text("Selected length: ${formatTime((endMs - startMs).coerceAtLeast(0L))}", color = White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(16.dp)); Button(onClick = { createDocument.launch("${track.title.replace(Regex("[^A-Za-z0-9 _-]"), "").take(35).ifBlank { "WaveTune-Trim" }}-trim.m4a") }, enabled = !exporting && endMs > startMs, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                if (exporting) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = White) else Icon(Icons.Default.FileDownload, null)
                Spacer(Modifier.width(8.dp)); Text(if (exporting) "Exporting…" else "Export trimmed M4A")
            }
            Spacer(Modifier.height(10.dp)); Text(editorMessage, color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
            Text("Note: stream-copy export works only when the source codec/container can be muxed into M4A. If export fails, try an AAC/M4A source. This tool does not re-encode or improve audio quality.", color = Color(0xFFFFD479), fontSize = 10.sp, lineHeight = 15.sp)
        }
    }
}

private fun trimAudioToM4a(resolver: android.content.ContentResolver, source: Uri, destination: Uri, startMs: Long, endMs: Long): String {
    var extractor: MediaExtractor? = null
    var muxer: MediaMuxer? = null
    var muxerStarted = false
    var outputPfd: ParcelFileDescriptor? = null
    return try {
        extractor = MediaExtractor()
        extractor.setDataSource(resolver.openAssetFileDescriptor(source, "r")!!.fileDescriptor)
        var audioTrack = -1
        var audioFormat: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) { audioTrack = i; audioFormat = format; break }
        }
        if (audioTrack < 0 || audioFormat == null) return "No audio stream was found in this file."
        outputPfd = resolver.openFileDescriptor(destination, "w") ?: return "Could not open the output file for writing."
        muxer = MediaMuxer(outputPfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        extractor.selectTrack(audioTrack)
        val outputTrack = muxer.addTrack(audioFormat)
        muxer.start(); muxerStarted = true
        val maxSize = if (audioFormat.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) audioFormat.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE).coerceAtLeast(256 * 1024) else 1024 * 1024
        val buffer = ByteBuffer.allocateDirect(maxSize)
        val info = MediaCodec.BufferInfo()
        val startUs = startMs * 1000L
        val endUs = endMs * 1000L
        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        var written = 0
        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            val sampleTime = extractor.sampleTime
            if (sampleTime > endUs) break
            if (sampleTime >= startUs) {
                info.set(0, size, (sampleTime - startUs).coerceAtLeast(0L), extractor.sampleFlags)
                buffer.position(0); buffer.limit(size)
                muxer.writeSampleData(outputTrack, buffer, info)
                written++
            }
            if (!extractor.advance()) break
        }
        muxer.stop(); muxerStarted = false
        if (written == 0) "No samples were found in that trim range. Try a wider selection." else "Export complete. Saved $written audio samples to your chosen M4A file."
    } catch (e: Exception) {
        "Export failed: ${e.localizedMessage ?: "this source codec may not be supported in M4A"}. Try an AAC/M4A source file."
    } finally {
        if (muxerStarted) runCatching { muxer?.stop() }
        runCatching { muxer?.release() }
        runCatching { extractor?.release() }
        runCatching { outputPfd?.close() }
    }
}

@Composable
private fun QueueScreen(queue: List<Track>, current: Track?, onClose: () -> Unit, onPlay: (Track) -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg).padding(14.dp)) {
        Column(Modifier.fillMaxSize().clip(RoundedCornerShape(28.dp)).background(Panel).padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("UP NEXT", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp); Text("Your queue", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold) }; IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = White) } }
            Text("${queue.size} tracks in this session", color = Muted, fontSize = 11.sp); Spacer(Modifier.height(10.dp))
            LazyColumn { itemsIndexed(queue) { index, track -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).clickable { onPlay(track) }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) { Text("${index + 1}", color = Muted, modifier = Modifier.width(27.dp)); AlbumGlyph(43); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(track.title, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(track.artist, color = Muted, fontSize = 11.sp) }; if (current?.uri == track.uri) Icon(Icons.Default.GraphicEq, null, tint = Cyan) } } }
        }
    }
}

@Composable
private fun AboutScreen(onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Bg).padding(14.dp)) {
        Column(Modifier.fillMaxSize().clip(RoundedCornerShape(28.dp)).background(Panel).padding(20.dp).verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("About WaveTune", color = White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f)); IconButton(onClick = onClose) { Icon(Icons.Default.Close, null, tint = White) } }
            Spacer(Modifier.height(8.dp)); Text("WaveTune • Feel every beat", color = Cyan, fontSize = 15.sp, fontWeight = FontWeight.Bold); Text("Version 2.0 • Made in India 🇮🇳", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(18.dp)); Text("Created by Ayush !!", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp)); Text("A local-first music player with a richer player, playback controls, an audio lab, queue, sleep timer and a trim/export tool for compatible audio files.", color = Color(0xFFD4DBF1), lineHeight = 22.sp)
            Spacer(Modifier.height(18.dp)); Text("Support WaveTune", color = Cyan, fontWeight = FontWeight.Bold); Text("If you choose to support future updates, scan the UPI QR below. Verify the recipient details before making a payment.", color = Muted, lineHeight = 19.sp)
            Spacer(Modifier.height(10.dp)); Image(painter = painterResource(id = R.drawable.support_qr), contentDescription = "UPI support QR code", modifier = Modifier.fillMaxWidth().heightIn(max = 330.dp).clip(RoundedCornerShape(18.dp)))
            Text("UPI ID: ayushku92sk@okicici", color = White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(18.dp)); Text("Privacy", color = Cyan, fontWeight = FontWeight.Bold); Text("WaveTune plays audio selected from your device. It does not unlock, scrape, or download tracks from streaming services. Playback features and export support depend on Android and source codecs.", color = Muted, fontSize = 11.sp, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun AnimatedWave(isPlaying: Boolean) {
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(if (isPlaying) 500 else 1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "phase")
    Canvas(Modifier.fillMaxWidth().height(44.dp)) {
        val bars = 54; val gap = 3.dp.toPx(); val barWidth = (size.width - gap * (bars - 1)) / bars
        for (i in 0 until bars) {
            val wave = abs(sin(i * 0.36 + phase * if (isPlaying) 7.5 else 2.2)).toFloat()
            val h = size.height * (0.12f + wave * (if (isPlaying) 0.76f else 0.34f))
            drawRoundRect(brush = Brush.verticalGradient(listOf(Cyan, Purple, Pink)), topLeft = androidx.compose.ui.geometry.Offset(i * (barWidth + gap), (size.height - h) / 2), size = androidx.compose.ui.geometry.Size(barWidth, h), cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth, barWidth))
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(totalSeconds / 60L, totalSeconds % 60L)
}
